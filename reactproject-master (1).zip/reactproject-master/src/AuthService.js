export const login = async ({ username, password }) => {
    // Replace this with real authentication logic
    return username === 'admin' && password === 'password';
  };
  