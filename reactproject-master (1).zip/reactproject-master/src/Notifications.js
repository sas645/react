import React from 'react';

function Notifications() {
  return (
    <div>
      <h2>Notifications</h2>
      <p>Low stock and sales updates will be displayed here.</p>
      {/* You can fetch data from the server and display notifications */}
    </div>
  );
}

export default Notifications;
