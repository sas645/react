import React from 'react';

function Dashboard() {
  // You can fetch data using axios (e.g., sales, inventory levels)
  return (
    <div>
      <h2>Dashboard</h2>
      <p>Overview of sales and inventory levels will go here.</p>
      {/* Display data from JSON Server here */}
    </div>
  );
}

export default Dashboard;

